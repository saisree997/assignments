package assignment1;

public class Sales extends Department{
	
		double appfactor = 10; 
		public double appfactor() {
			return appfactor;
		}
		
	

}
