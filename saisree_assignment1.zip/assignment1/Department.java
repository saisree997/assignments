package assignment1;

import java.io.EOFException;

public class Department {
	
 double appfactor;
 
 
public   double getappfactor(String dept) {
	try {
		if(dept!=null & dept.equals("Developer")) {
			Developer dev = new Developer();
			 appfactor  = dev.appfactor();
		}
			else if(dept!=null & dept.equals("Sales")) {
				Sales sale = new Sales();
				 appfactor  = sale.appfactor;
			}
			else if(dept!=null & dept.equals("Operation")) {
				Operation ope = new Operation();
				 appfactor  = ope.appfactor;
			}
			else if(dept!=null & dept.equals("Manager")) {
				Manager mang = new Manager();
				 appfactor  = mang.appfactor;
			}
			else
			{
			}
	}
	
	catch(Exception e) {
		e.printStackTrace();
	}
	return appfactor;
	
	}

}
