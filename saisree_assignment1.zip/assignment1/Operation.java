package assignment1;

public class Operation extends Department{
	
		double appfactor = 8; 
		public double appfactor() {
			return appfactor;
		}
		
	
}
