package assignment1;

public class Manager extends Department{

		double appfactor = 12; 
		public double appfactor() {
			return appfactor;
		}
		
	
}
