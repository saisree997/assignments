package assignment1;

public class Developer extends Department {

		double appfactor = 15;	
	public double appfactor() {
		return appfactor;
	}

}
