package assignment2;

import java.util.ArrayList;
import java.util.Arrays;

public class hotels {

	public static restaurant[] getRestaurants() {

		ArrayList<String> feedback = new ArrayList<String>();

		restaurant Bawarchi = new restaurant("Bawarchi", feedback, 0);
		Bawarchi.feedback.add("best place for awesome biryani and good kababs");

		restaurant Paradise = new restaurant("Paradise", feedback, 0);
		Paradise.feedback.add("This is good place for Biryani,Nice to have mutton biryani");

		restaurant Ohri = new restaurant("Ohri", feedback, 0);
		Ohri.feedback.add("Nice for vegetable lovers,Just Okay");

		restaurant Angara = new restaurant("Angara", feedback, 0);
		Angara.feedback.add("Not what i expected");

		restaurant[] Restaurants = { Bawarchi, Paradise, Ohri, Angara };

		return Restaurants;

	}

	public static String[] GetFeedbacks(ArrayList<String> feedback) {

		// Convert ArrayList to object array
		Object[] objArr = feedback.toArray();

		// convert Object array to String array
		String[] str = Arrays.copyOf(objArr, objArr.length, String[].class);
		return str;
	}

}
