package assignment2;

import java.util.ArrayList;

import assignment1.Employee;

public class restaurant implements Comparable<restaurant> {
	String name = "";
	ArrayList feedback;
	int frequency = 0;

	public restaurant(String name, ArrayList feedback, int frequency) {
		this.name = name;
		this.feedback = feedback;
		this.frequency = frequency;
	}

	public void setFeedaback(ArrayList feedback) {
		this.feedback = feedback;
	}

	public ArrayList getFeedback() {
		return feedback;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getName() {
		return name;
	}

	public int getFrequency() {
		return frequency;
	}

	public void setFrequency(int frequency) {
		this.frequency = frequency;
	}

	@Override
	public int compareTo(restaurant r) {

		if (frequency == r.frequency)
			return 0;
		else if (frequency < r.frequency)
			return -1;
		else
			return 1;
	}

}
